require 'faye/websocket'
require 'eventmachine'
require 'json'
require 'sinatra'
require 'sinatra-websocket'
require 'mysql2'

#DB connection with this got some errors realted to COCOPad issues with MAC with Chip M1
require 'sequel'


db ||= Sequel.connect(
  adapter: 'mysql2',
  host: 'localhost',
  username: 'root',
  password: '',
  database: 'shoe_stores',
)
# DB = Sequel.connect('postgres://yashu:yashu@localhost:5432/shoes_store_test')

get '/' do
  erb :index
end

get '/websocket' do
    stream(:keep_open) do |out|
    #create a WebSocket connection
        EM.run {
            ws = Faye::WebSocket::Client.new('ws://localhost:8080/')
            ws.on :message do |event|
            json_data = JSON.parse(event.data)

               db_data = db[:shops_inventory].where(store: json_data["store"], model: json_data["model"])
               if db_data.empty?
                 db_data.insert(store: json_data["store"], model: json_data["model"], inventory: json_data["inventory"])
                elsif db_data[:inventory] != json_data["inventory"]
                  p "the db data before update is #{db_data[:inventory]}"
                  db_data.update(inventory: json_data["inventory"])
                end
                  
                if json_data["inventory"] <= 10
                    json_data["Message"] = "Product #{json_data["store"]} #{json_data["model"]} is running out of Stock "
                elsif json_data["inventory"] >= 95
                    json_data["Message"] = "Hell No! Super sale is here for #{json_data["store"]} #{json_data["model"]}"
                end

                out << json_data
            end
            ws.on :close do |event|
                ws = nil
            end
        }
    end
end










#websockets with EventMachine 

# EventMachine.stop

# EventMachine.run do

#     #Using sinatra framework
#     class App < Sinatra::Base
#         get '/' do
#           erb :index
#         end
#     end

#     @clients =[]
#     # Websockets connection 
#     ws = Faye::WebSocket::Client.new('ws://localhost:8080/')


#     ws.onopen = lambda do |event|
#         @clients << event.data
#         p [:open]
#         ws.send(event.data)
#         @clients.each do |socket|
#             socket.send event.data
#         end
#     end

#     # ws.onmessage = lambda do |event|
#     #     p [:message, event.data]
#     #     ws.send(event.data)

#     # end

#     ws.onclose = lambda do |event|
#         p [:close, event.code, event.reason]
#         ws = nil
#         # @clients.delete ws
#     end

#     # EM::WebSocket.start(:host => '0.0.0.0', :port => '3001') do |ws|
#     #     ws.onopen do |handshake|
#     #       @clients &lt;&lt; ws
#     #       ws.send 'Connected to #{handshake.path}.'
#     #     end

#     #     ws.onclose do
#     #       ws.send 'Closed.'
#     #       @clients.delete ws
#     #     end

#     #     ws.onmessage do |msg|
#     #       puts 'Received Message: #{msg}'
#     #       @clients.each do |socket|
#     #         socket.send msg
#     #       end
#     #     end
#     # end


#   #Running Sintara app at port locahost:3000
#   App.run! :port => 3000
# end

# EventMachine.stop


#with eventmachine and faye code as below
  # ws = Faye::WebSocket::Client.new('ws://localhost:8080/')

  # ws.on :message do |event|
  #   @json_data = JSON.parse(event.data)
  #   p @json_data
  # end
  # ws.onopen = lambda do |event|
  #   p [:open]
  #   ws.send('Hello, world!')
  # end

  # ws.onmessage = lambda do |event|
  #   p [:message, event.data]
  # end

  # ws.onclose = lambda do |event|
  #   p [:close, event.code, event.reason]
  #   ws = nil
  # end

